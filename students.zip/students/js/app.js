angular.module('studentApp', [
  'studentApp.controllers'
]);