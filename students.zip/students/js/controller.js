function student(id, name, section) {
    this.id = id;
    this.name = name;
    this.section = section;
}

function studentList() {


    this.students = [];

}

studentList.prototype.addStudent = function(stud) {


    for (var i = 0; i < this.students.length; i++) {

        if (stud.id === this.students[i].id) {
            this.students[i].name = stud.name;
            this.students[i].section = stud.section;
            return
        };
    };

    var newStudent = new student(stud.id,
        stud.name,
        stud.section);
    console.log("New student added: " + newStudent.id);
    this.students.push(newStudent);
}

studentList.prototype.getStudent = function(studId) {

    for (var i = 0; i < this.students.length; i++) {

        if (studId === this.students[i].id) {

            return new student(this.students[i].id,
                this.students[i].name,
                this.students[i].section);
        }
    }
}

angular.module('studentApp', [])
    .controller('studentController', ['$scope', function($scope) {

        $scope.studList = new studentList();
        console.log("Student List obj created");
        $scope.idDisable = false;

        $scope.submit = function() {
            var stud = new student($scope.studentForm.id,
                $scope.studentForm.name,
                $scope.studentForm.section);

            $scope.studList.addStudent(stud);

            $scope.studentForm = null;
            $scope.idDisable = false;
            document.getElementById("id").focus();
        };

        $scope.clear = function() {

            $scope.idDisable = false;

            document.getElementById("id").focus();
        }

        $scope.edit = function(studId) {


            $scope.studentForm = $scope.studList.getStudent(studId);
            $scope.idDisable = true;
            document.getElementById("name").focus();
        }

        $scope.writeToConsole = function() {
            console.log(JSON.stringify($scope.studList.students));
        }

        $scope.loadData = function() {
            httpRequest = new XMLHttpRequest();

            httpRequest.onreadystatechange = function() {
                try {
                    if (httpRequest.readyState === XMLHttpRequest.DONE) {
                        if (httpRequest.status === 200) {
                            console.log(httpRequest.responseText);
                            var loadedData = JSON.parse(httpRequest.responseText);
                            console.log(loadedData);
                            for (var i =0; i < loadedData.length; i++) {
                              $scope.studList.addStudent(new student(loadedData[i].id,
                                  loadedData[i].name,
                                  loadedData[i].section));
                            }

                        } else {
                            alert('There was a problem with the request.');
                        }
                    }
                } catch (e) {
                    alert('Caught Exception: ' + e);
                }
            }
            try {
                httpRequest.open('GET', '../data/student.json');
                httpRequest.send(null);

            } catch (e) {
                console.log("Raised an exception" + e);
            }
        }
    }])
